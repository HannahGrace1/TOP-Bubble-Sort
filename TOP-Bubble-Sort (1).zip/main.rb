def bubble_sort(element)
  sorted =true

  
  while sorted
    sorted= false
     (element.size - 1).times do |i|
    if element[i] > element[i+1]
        element[i],element [i+1] = element[i+1],element[i]
        sorted = true
      end
    end
  end
  element
end

  
   
puts bubble_sort([4,3,78,2,0,2])
# => [0,2,2,3,4,78]





    